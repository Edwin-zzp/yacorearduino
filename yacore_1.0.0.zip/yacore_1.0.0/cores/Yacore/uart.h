#ifndef _UART_H_
#define _UART_H_

#ifdef __cplusplus
extern "C"{
#endif

#define UART0_BASE      (0x4A101000)
#define UART0_DATA      (UART0_BASE + (0x00))
#define UART0_IER       (UART0_BASE + (0x04))
#define UART0_FCR       (UART0_BASE + (0x08))
#define UART0_LCR       (UART0_BASE + (0x0C))
#define UART0_MCR       (UART0_BASE + (0x10))
#define UART0_LSR       (UART0_BASE + (0x14))
#define UART0_MSR       (UART0_BASE + (0x18))
#define UART0_DLL       (UART0_BASE + (0x00))
#define UART0_DLM       (UART0_BASE + (0x04))

#define UART0_REG(addr) (*((volatile uint32_t *)addr))

void uart_init();
void uart_putc(uint8_t c);
uint8_t uart_getc();

#ifdef __cplusplus
}
#endif

#endif
