#include <stdint.h>

#include "./uart.h"
#include "./xprintf.h"

#define CLK_HZ 50000000
#define BAUD    (115200*16)


// send one char to uart
void uart_putc(uint8_t c)
{  
    UART0_REG(UART0_DATA) = c;
    while ((UART0_REG(UART0_LSR) & 0x40) ==0);
}

// Block, get one char from uart.
uint8_t uart_getc()
{
    // UART0_REG(UART0_STATUS) &= ~0x2;
    while ((UART0_REG(UART0_LSR) & 0x01) == 0);
    return (UART0_REG(UART0_DATA) & 0xff);
}

// 115200bps, 8 N 1
void uart_init()
{
    // enable tx and rx
    // UART0_REG(UART0_CTRL) = 0x3;
    UART0_REG(UART0_LCR) = 0x83;

    UART0_REG(UART0_DLM) = ((CLK_HZ/BAUD)>>8) & 0xFF;
    UART0_REG(UART0_DLL) = ((CLK_HZ/BAUD)>>0) & 0xFF;
    UART0_REG(UART0_FCR) = 0x41;
    UART0_REG(UART0_LCR) = 0x03;
    UART0_REG(UART0_IER) = 0x00;


    xdev_out(uart_putc);
}


